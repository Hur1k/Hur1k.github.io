# HWS-winter

Created: January 7, 2023 11:32 AM
URL: https://hws2023.lordcasser.com/rank/1?time=1,673,226,798,823
复现没！: No

![Untitled](HWS-winter%20cfa00215f7f6423e824f007eff4f21ff/Untitled.png)

# WriteUps

# 总结

结束咯~这几天睡得真不踏实，半夜还在想题目￣へ￣，希望以后比赛的时候睡得好一点

这次Crypto和Misc全靠现搜现用，也慢慢的开始学会看源码了，挺好的~

RE方面可以说接触到很多新的知识了，特别是repy😭这是第一次接触控制流平坦化了，已经大头pyc，这已经是第四次反编译pyc失败了🤐离part3的flag就差亿点点，亿点点

最后是拿到了11名啦~还是比心理预期要高的，可能大佬们都去打rwctf了吧

# 战利品

# wp-release

![Untitled](HWS-winter%20cfa00215f7f6423e824f007eff4f21ff/Untitled%201.png)

[](https://www.notion.so/cdcf826896e241f199e8ec0d864944cd)